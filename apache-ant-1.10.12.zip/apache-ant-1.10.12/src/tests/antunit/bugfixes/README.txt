This directory contains tests for the bugs
that have been fixed.
