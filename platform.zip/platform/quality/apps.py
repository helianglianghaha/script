from django.apps import AppConfig


class QualityConfig(AppConfig):
    name = 'quality'
