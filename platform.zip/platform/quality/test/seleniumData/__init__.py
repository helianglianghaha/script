__all__ = ['base', 'keywords','locatorsList','log','function']
connectList=[]

if __name__ == '__main__':
    print("parent作为主程序运行")
else:
    print("parent初始化")