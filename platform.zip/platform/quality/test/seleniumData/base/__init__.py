# __all__=['context','librarycomponent']
if __name__=="__main__":
    print("base作为主程序运行")
else:
    print("base初始化")