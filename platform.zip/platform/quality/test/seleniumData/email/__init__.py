# __all__=['context','librarycomponent']
if __name__=="__main__":
    print("email作为主程序运行")
else:
    print("email初始化")