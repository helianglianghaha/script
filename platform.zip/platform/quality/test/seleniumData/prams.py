connectionList={}
handles=[]
assertList=['']