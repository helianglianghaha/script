__all__=['typeslist']
if __name__=="__main__":
    print("util作为主程序运行")
else:
    print("util初始化")