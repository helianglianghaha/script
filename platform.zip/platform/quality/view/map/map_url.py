# from django.urls import path,re_path
# from quality.view.map import map
# app_name="map"

# urlpatterns = [
#     path('/selectOverAll/$',map.selectOverAll,name='selectOverAll'),
#     path('/saveOverAll/$',map.saveOverAll,name='saveOverAll'),
#     path('/getDateTime/$',map.getDateTime,name='getDateTime'),
#     path('/getMapProjectData/$',map.getMapProjectData,name='getMapProjectData'),
# ]